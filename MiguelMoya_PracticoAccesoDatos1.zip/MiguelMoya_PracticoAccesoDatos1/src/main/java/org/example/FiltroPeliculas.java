package org.example;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;


public class FiltroPeliculas {
    public void filtrarPorGenero(String genero) throws IOException {
       File nuevoCSV= CrearFichero(new File(genero + ".csv"));
        FileReader fR = new FileReader("peliculas.csv");
        BufferedReader bF = new BufferedReader(fR);

        String linea;
        StringBuilder generoR = new StringBuilder();
        while ((linea = bF.readLine()) != null) {
            char letra;
            int count=0;
            for (int i = 0; i <linea.length() ; i++) {
                letra=linea.charAt(i);
                if (letra==','){
                    count++;
                }
                if (count==3)
                generoR.append(letra);
            }
            if (generoR.toString().equals(genero)){
                EscribirFichero(nuevoCSV,linea);
            }

        }

        bF.close();
        fR.close();

    }
    public static File CrearFichero(File fichero) throws IOException {

        if (fichero.createNewFile()) {
            System.out.println("Fichero creado correctamente");
        } else {
            System.out.println("El fichero ya exixte");
        }
        return fichero;
    }

    public static void EscribirFichero(File fichero, String message) throws IOException {
        FileWriter fW = new FileWriter(fichero, true);
        fW.write(message + "\n");
        fW.close();
    }


}
