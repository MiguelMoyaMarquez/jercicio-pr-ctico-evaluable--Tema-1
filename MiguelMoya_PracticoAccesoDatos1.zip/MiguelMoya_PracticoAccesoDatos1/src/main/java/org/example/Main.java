package org.example;


import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        FiltroPeliculas fP=new FiltroPeliculas();

        fP.filtrarPorGenero("Drama");
    }
}